/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Negocio.Modelo;
import Negocio.Control.Persona;
import java.util.Vector;
import javax.swing.JOptionPane;
/**
 *
 * @author eloy011
 */
public class agenda {
    Vector vector = new Vector();
    Persona persona = new Persona();
    
    public void GuardarPersona(Persona persona) {
        
        if(vector.add(persona)) {
            JOptionPane.showMessageDialog(null,"Se ha agregado correctamente la persona");
        }
    }
    
}
