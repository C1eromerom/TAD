/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Negocio.Control;

/**
 *
 * @author eloy011
 */
public class Persona {
    
    public String Nombre;
    public String Apellidos;
    public String Rut;
    public String Email;
    public String Telefono;
    
    public Persona(String Nombre, String Apellidos, String Rut, String Email, String Telefono) {
        this.Nombre = Nombre;
        this.Apellidos = Apellidos;
        this.Rut = Rut;
        this.Email = Email;
        this.Telefono = Telefono;
        
    }
    
    public Persona () {
     }
}